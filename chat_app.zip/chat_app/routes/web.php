<?php

use App\Http\Controllers\Main_controller;
use App\Http\Controllers\UserController;
use Illuminate\Contracts\Auth\UserProvider;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get("/",[Main_controller::class,"home"])->name('main.home');
Route::post("/signup",[Main_controller::class,"signup"])->name('main.signup');
Route::get("/login",[Main_controller::class,"login"])->name('main.login');
Route::post("/login_verify",[Main_controller::class,"login_verify"])->name('main.verify_login');
Route::get("/forgot_password",[Main_controller::class,"forgot_password"])->name('main.forgot_password');
Route::post("/forgot_password_submit",[Main_controller::class,"submit_forget_password"])->name('main.submit_forgot_password');
Route::get("/create_new_password",[Main_controller::class,"create_new_password"])->name('main.create_new_password');
Route::post("/new_password_update",[Main_controller::class,"new_password_update"])->name('main.new_password_change');


//user content start
Route::group(["prefix"=>"user","as"=>"user."],function(){

Route::get("/dashboard",[UserController::class,"dashboard"])->name('dashboard');
Route::get("/logout",[UserController::class,"logout"])->name('logout');
Route::post("/friend_search",[UserController::class,"friend_search"])->name('friend_search');
Route::get("/messenger/{id?}",[UserController::class,"go_to_chats"])->name('chats');
Route::get("/settings",[UserController::class,"settings"])->name('settings');
Route::post("/add_friend",[UserController::class,"add_friend"])->name('add_friend');
Route::post("/send_message",[UserController::class,"send_message"])->name('send_message');
Route::post("/user_data_update",[UserController::class,"user_data_update"])->name('user_data_update');
Route::get("/profile",[UserController::class,"profile"])->name('profile');
Route::post("/update_profile",[UserController::class,"update_profile"])->name('update_profile');
Route::post("/security_question_add",[UserController::class,"security_question_add"])->name('security_question');
Route::get("/change_password",[UserController::class,"change_password"])->name('change_password');
Route::post("/update_password",[UserController::class,"update_password"])->name('update_password');
});
//user content end
