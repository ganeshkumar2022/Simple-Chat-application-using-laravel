<?php

namespace App\Http\Controllers;

use App\Models\Chat_wit_friend;
use App\Models\Country;
use App\Models\Messages;
use App\Models\User;
use App\Models\UserLog;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;

class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware('user_login_authentication');
    }
    public function dashboard()
    {

        $id=session('uid');

        $users=User::join('countries','countries.id','=','users.country')->where('users.id',"!=",$id)->select("users.*","countries.*","users.id as uid")->get();
        return view('user.dashboard',['users'=>$users]);
    }
    public function friend_search(Request $request)
    {


        $id=session('uid');

        $search=trim(strip_tags($request->input('name')));
        if(empty($search))
        {
            $users=User::join('countries','countries.id','=','users.country')->where('users.id',"!=",$id)->select("users.*","countries.*","users.id as uid")->get();
        }
        else
        {
            $users=User::join('countries','countries.id','=','users.country')->where('users.id',"!=",$id)->where('users.name',"like","%$search%")->select("users.*","countries.*","users.id as uid")->get();
        }
        return view('user.dashboard',['users'=>$users]);

    }
    public function profile()
    {
        $id=session('uid');
        $user=User::find($id);
        return view('user.profile',compact('user'));
    }
    public function update_profile(Request $request)
    {
        $request->validate([
            'profile_image'=>'required|image|mimes:jpeg,png,jpg|max:2048'
        ]);

        $id=session('uid');
        $user=User::find($id);

        $pro=public_path("profile_images/".$user->profile_image);

        if($files=$request->file('profile_image'))
        {
            $name=$files->getClientOriginalName();
            $extension=$files->getClientOriginalExtension();
            $a=rand(100000,999999);
            $new_file=(string)$a.".".$extension;
            $files->move('profile_images',$new_file);
            $user->profile_image=$new_file;

        }

        try
        {
            $user->save();

            if(File::exists($pro))
            {
                File::delete($pro);
            }

            $message="Profile Updated successfully";
            return redirect()->route('user.profile')->with('success',$message);
        }
        catch(Exception $e)
        {
            $message="Error to Update Profile";
            return redirect()->route('user.profile')->with('error',$message);
        }

    }
    public function go_to_chats($id=null)
    {
        $user_id=session('uid');
        $chat_with=User::find($id);
        $iam=User::find($user_id);
        /*$friends2_get=Chat_wit_friend::join('users','users.id','=','chat_wit_friends.friend_id')->leftJoin('user_logs','user_logs.user_id','=','users.id')->where('chat_wit_friends.user_id',$user_id)->select('users.*','user_logs.is_active')->get();*/
        $friends_get=User::join('chat_wit_friends','chat_wit_friends.friend_id','=','users.id')->leftJoin('user_logs','user_logs.user_id','=','users.id')->where('chat_wit_friends.user_id',$user_id)->select('users.*','user_logs.is_active')->get();

        $reply_user=Messages::whereIn('receiver_id',[$user_id])->get();
        $my_messages=Messages::whereIn('from_id',[$user_id,$id])->whereIn('receiver_id',[$user_id,$id])->get();


        return view('user.chat_page',compact('friends_get','chat_with','my_messages','iam'));
    }
    public function settings()
    {
        $id=session('uid');
        $user=User::find($id);
        $countries=Country::orderBy('country_name','asc')->get();
        return view('user.settings',compact('user','countries'));
    }
    public function change_password()
    {
        return view('user.change_password');
    }
    public function update_password(Request $request)
    {
        $request->validate([
            'current_password'=>'required|regex:/^[a-zA-Z0-9\s.,#$&@!~*=]+$/',
            'new_password'=>'required|regex:/^[a-zA-Z0-9\s.,#$&@!~*=]+$/',
            'confirm_password'=>'required|regex:/^[a-zA-Z0-9\s.,#$&@!~*=]+$/'
        ],[
            'current_password.regex'=>'Current password not valid format',
            'new_password.regex'=>'New password not valid format',
            'confirm_password.regex'=>'Confirm password not valid format'
        ]);

        $current_password=$request->input('current_password');
        $new_password=$request->input('new_password');
        $confirm_password=$request->input('confirm_password');

        if($new_password!=$confirm_password)
        {
            $message="New password and confirm password not match";
            return redirect()->route('user.change_password')->with('error',$message);

            exit;
        }

        $id=session('uid');
        $user=User::find($id);

        if(!password_verify($current_password,$user->password))
        {
            $message="Current password not match";
            return redirect()->route('user.change_password')->with('error',$message);

            exit;
        }
        else
        {
            $pass=password_hash($new_password,PASSWORD_DEFAULT);
            $user->password=$pass;
            try
            {
                $user->save();
                $message="Password updated";
                return redirect()->route('user.change_password')->with('success',$message);
            }
            catch(Exception $e)
            {
                $message="Error to update password";
                return redirect()->route('user.change_password')->with('error',$message);
            }
        }

    }
    public function security_question_add(Request $request)
    {
        $request->validate([
            'friend_name'=>'required|string|min:2|max:50|regex:/^[a-zA-Z\s]+$/',
        ],[
            'friend_name.regex'=>'Name pattern not valid'
        ]);

        $id=session('uid');
        $user=User::find($id);
        $user->security_question=$request->input('friend_name');

        try
        {
            $user->save();
            $message="Security Question Answered successfully";
            return redirect()->route('user.settings')->with('success',$message);
        }
        catch(Exception $e)
        {
            $message="Error to Add";
            return redirect()->route('user.settings')->with('error',$message);
        }
    }
    public function user_data_update(Request $request)
    {

        $id=session('uid');
        $request->validate([
            'name'=>'required|string|min:2|max:50|regex:/^[a-zA-Z0-9\s]+$/',
            'email'=>'required|email|unique:users,email,'.$id,
            'country'=>'required|numeric',
            'gender'=>'required|max:10|regex:/^[a-zA-Z\s]+$/'
        ],[
            'country.numeric'=>'Country name not valid'
        ]);

        $user=User::find($id);
        $user->name=$request->input('name');
        $user->email=$request->input('email');
        $user->country=$request->input('country');
        $user->gender=$request->input('gender');

        try
        {
            $user->save();
            $message="Updated successfully";
            return redirect()->route('user.settings')->with('success',$message);
        }
        catch(Exception $e)
        {
            $message="Error to Update";
            return redirect()->route('user.settings')->with('error',$message);
        }
    }
    public function add_friend(Request $request)
    {
        $friend_id=$request->input('friend_id');
        $user_id=session('uid');

        $friends=Chat_wit_friend::where('friend_id',$friend_id)->where('user_id',$user_id)->get();
        if(count($friends)>0)
        {
            return redirect()->route('user.chats',$friend_id);
        }
        else
        {
            $friend=new Chat_wit_friend();
            $friend->friend_id=$friend_id;
            $friend->user_id=$user_id;


            $friend2=new Chat_wit_friend();
            $friend2->friend_id=$user_id;
            $friend2->user_id=$friend_id;
            try
            {
            $friend->save();
            $friend2->save();
            return redirect()->route('user.chats',$friend_id);
            }
            catch(Exception $e)
            {
                return redirect()->route('user.dashboard')->with('error','Error to start chat');
            }
        }
    }
    public function send_message(Request $request)
    {
        $request->validate([
            'message'=>'required'
        ]);
        $from_id=session('uid');
        $message=strip_tags($request->input('message'));
        $receiver_id=strip_tags($request->input('receiver_id'));

        $send_message=new Messages();
        $send_message->from_id=$from_id;
        $send_message->message=$message;
        $send_message->receiver_id=$receiver_id;
        $send_message->save();
        return redirect()->route('user.chats',$receiver_id);

    }
    public function logout()
    {
        //user log start
        UserLog::where('user_id',session('uid'))->delete();
        //user log end

        session()->forget('uid');
        session()->flush();
        return redirect()->route('main.login');
    }

}
