<?php

namespace App\Http\Controllers;

use App\Models\Country;
use App\Models\User;
use App\Models\UserLog;
use Exception;
use Illuminate\Http\Request;

class Main_controller extends Controller
{
    public function home()
    {
        $countries=Country::orderBy('country_name','asc')->get();
        return view('home',compact('countries'));
    }
    public function signup(Request $request)
    {
        $request->validate([
            'name'=>'required|string|min:2|max:50|regex:/^[a-zA-Z0-9\s]+$/',
            'email'=>'required|email|unique:users,email',
            'password'=>'required|min:5|regex:/^[a-zA-Z0-9\s.,#$&@!~*=]+$/',
            'country'=>'required|numeric',
            'gender'=>'required|max:10|regex:/^[a-zA-Z\s]+$/',
            'remember'=>'required'
        ],[
            'country.numeric'=>'Country name not valid',
            'remember.required'=>'Please accept the terms and conditions to continue'
        ]);

        $user=new User();
        $user->name=$request->input('name');
        $user->email=$request->input('email');
        $user->password=password_hash($request->input('password'),PASSWORD_DEFAULT);
        $user->country=$request->input('country');
        $user->gender=$request->input('gender');

        try
        {
            $user->save();
            $message="Inserted successfully";
            return redirect()->route('main.home')->with('success',$message);
        }
        catch(Exception $e)
        {
            $message="Error to Insert";
            return redirect()->route('main.home')->with('error',$message);
        }


    }
    public function login()
    {
        return view('login');
    }
    public function login_verify(Request $request)
    {
        $request->validate([
            'email'=>'required|email',
            'password'=>'required|regex:/^[a-zA-Z0-9\s.,#$&@!~*=]+$/'
        ]);


        $email=$request->input('email');
        $password=$request->input('password');

        $user=User::where('email',$email)->first();
        if($user)
        {
            if(password_verify($password,$user->password))
            {
                $message="Login Successfully";


                session()->put('uid',$user->id);
                UserLog::where('user_id',session('uid'))->delete();
                //user log start
                $log=new UserLog();
                $log->user_id=$user->id;
                $log->is_active=1;
                $log->save();
                //user log end

                return redirect("/user/dashboard");
            }
            else
            {
                $message="Email or password incorrect";
                return redirect()->route('main.login')->with('error',$message);
            }
        }
        else
        {
            $message="Email or password incorrect";
            return redirect()->route('main.login')->with('error',$message);
        }
    }
    public function forgot_password()
    {
        return view('forgot_password');
    }
    public function submit_forget_password(Request $request)
    {
        $request->validate([
            'email'=>'required|email',
            'friend_name'=>'required|regex:/^[a-zA-Z\s]+$/'
        ]);


        $email=$request->input('email');
        $friend_name=$request->input('friend_name');

        //check security question write or not
        $user=User::where('email',$email)->first();
        if($user)
        {
            if($user->security_question==$friend_name)
            {
                $message="Login Successfully";


                session()->put('forgot_id',$user->id);
                return redirect("/create_new_password");
            }
            else
            {
                $message="Email or security question answer incorrect";
                return redirect()->route('main.forgot_password')->with('error',$message);
            }
        }
        else
        {
            $message="Email Not exists";
            return redirect()->route('main.forgot_password')->with('error',$message);
        }
         //check security question write or not
    }
    public function create_new_password()
    {
        if(session()->has('forgot_id'))
        {
            return view('create_new_password');
        }
        else
        {
            return redirect()->route('main.forgot_password');
        }

    }
    public function new_password_update(Request $request)
    {
        if(session()->has('forgot_id'))
        {
            $request->validate([
                'new_password'=>'required|regex:/^[a-zA-Z0-9\s.,#$&@!~*=]+$/',
                'confirm_password'=>'required|regex:/^[a-zA-Z0-9\s.,#$&@!~*=]+$/'
            ]);

            $new_password=$request->input('new_password');
            $confirm_password=$request->input('confirm_password');

            if($new_password!==$confirm_password)
            {
                $message="New password and confirm password not match";
                return redirect()->route('main.create_new_password')->with('error',$message);
            }
            else
            {
                $new_password=password_hash($new_password,PASSWORD_DEFAULT);
                $id=session('forgot_id');
                $user=User::find($id);
                $user->password=$new_password;

                try
                {
                    $user->save();
                    $message="Password Updated successfully. Login to Continue";
                    return redirect()->route('main.login')->with('success',$message);
                }
                catch(Exception $e)
                {
                    $message="Error to Update password";
                    return redirect()->route('main.login')->with('error',$message);
                }


            }


        }
    }
}
