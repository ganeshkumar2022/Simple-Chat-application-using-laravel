-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 06, 2025 at 01:37 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chat_application`
--

-- --------------------------------------------------------

--
-- Table structure for table `chat_wit_friends`
--

CREATE TABLE `chat_wit_friends` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `friend_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chat_wit_friends`
--

INSERT INTO `chat_wit_friends` (`id`, `user_id`, `friend_id`, `created_at`, `updated_at`) VALUES
(11, 3, 4, '2024-12-28 00:12:06', '2024-12-28 00:12:06'),
(12, 4, 3, '2024-12-28 00:12:20', '2024-12-28 00:12:20'),
(13, 3, 8, '2025-01-01 23:30:13', '2025-01-01 23:30:13'),
(14, 8, 3, '2025-01-03 23:04:06', '2025-01-03 23:04:06'),
(15, 3, 9, '2025-01-06 03:10:23', '2025-01-06 03:10:23'),
(16, 9, 3, '2025-01-06 03:10:45', '2025-01-06 03:10:45'),
(17, 3, 7, '2025-01-06 05:19:05', '2025-01-06 05:19:05'),
(18, 7, 4, '2025-01-06 05:19:36', '2025-01-06 05:19:36'),
(19, 7, 3, NULL, NULL),
(20, 7, 9, '2025-01-06 05:24:05', '2025-01-06 05:24:05'),
(21, 9, 7, '2025-01-06 05:24:05', '2025-01-06 05:24:05'),
(22, 9, 4, '2025-01-06 05:24:38', '2025-01-06 05:24:38'),
(23, 4, 9, '2025-01-06 05:24:38', '2025-01-06 05:24:38');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `country_name` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `country_name`, `created_at`, `updated_at`) VALUES
(1, 'India', NULL, NULL),
(2, 'Pakistan', NULL, NULL),
(3, 'China', NULL, NULL),
(4, 'Nepal', NULL, NULL),
(5, 'Bangladesh', NULL, NULL),
(6, 'Sri Lanka', NULL, NULL),
(7, 'Afghanistan', NULL, NULL),
(8, 'Bhutan', NULL, NULL),
(9, 'Maldives', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `from_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `from_id`, `message`, `receiver_id`, `created_at`, `updated_at`) VALUES
(21, 3, 'hi', 4, '2024-12-28 00:12:10', '2024-12-28 00:12:10'),
(22, 4, 'hello', 3, '2024-12-28 00:12:27', '2024-12-28 00:12:27'),
(23, 3, 'enna panra', 4, '2024-12-28 00:16:16', '2024-12-28 00:16:16'),
(24, 4, 'paatu kekura', 3, '2024-12-28 00:16:31', '2024-12-28 00:16:31'),
(25, 4, 'good night', 3, '2024-12-28 00:17:16', '2024-12-28 00:17:16'),
(26, 3, 'good night sweet dreams', 4, '2024-12-28 00:17:31', '2024-12-28 00:17:31'),
(27, 3, 'hi', 8, '2025-01-01 23:30:19', '2025-01-01 23:30:19'),
(28, 3, 'hi', 8, '2025-01-03 23:03:43', '2025-01-03 23:03:43'),
(29, 8, 'saptiya', 3, '2025-01-03 23:04:13', '2025-01-03 23:04:13'),
(30, 3, 'mm', 8, '2025-01-03 23:04:26', '2025-01-03 23:04:26'),
(31, 3, 'hi', 9, '2025-01-06 03:10:28', '2025-01-06 03:10:28'),
(32, 9, 'hello', 3, '2025-01-06 03:10:50', '2025-01-06 03:10:50'),
(33, 3, 'hi', 7, '2025-01-06 05:20:33', '2025-01-06 05:20:33'),
(34, 7, 'hello', 3, '2025-01-06 05:20:40', '2025-01-06 05:20:40'),
(35, 7, 'hi', 9, '2025-01-06 05:24:09', '2025-01-06 05:24:09'),
(36, 9, 'hello', 7, '2025-01-06 05:25:09', '2025-01-06 05:25:09');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2024_12_19_132254_create_users_table', 1),
(6, '2024_12_20_125852_create_countries_table', 1),
(7, '2024_12_24_053912_create_chat_wit_friends_table', 2),
(8, '2024_12_26_112821_add_profile_column_users', 3),
(9, '2024_12_27_045428_create_messages_table', 4),
(11, '2024_12_28_055140_create_user_logs_table', 5),
(12, '2025_01_03_080102_add_column_security_question', 6);

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `country` int(11) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `profile_image` varchar(200) DEFAULT NULL,
  `security_question` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `password`, `email`, `country`, `gender`, `created_at`, `updated_at`, `profile_image`, `security_question`) VALUES
(3, 'ganeshkumar', '$2y$10$TsmXUVBl8k7z.1oGEA0kaOzzpNtB3Tm83Jwpji3mmg3cmzpgoPjSO', 'ganesh@gmail.com', 1, 'male', '2024-12-21 04:12:53', '2025-01-06 03:09:22', '789073.jpg', 'somanathg'),
(4, 'nandhini', '$2y$10$oC/NVLqLxkh8gJSQ1xPDuu1qpFYTlGGX8AuVBWjuEn8Z8UIWrUd0y', 'nandhini@gmail.com', 2, 'female', '2024-12-21 04:13:29', '2025-01-03 23:10:41', '431177.jpg', 'kayal'),
(5, 'naruto', '$2y$10$14xROH2/WUKS4/86AD8Sb.mRv5Q8SY14bHXxXnafRisi3kHeOxxLa', 'naruto@gmail.com', 6, 'male', '2024-12-21 04:15:49', '2024-12-21 04:15:49', NULL, NULL),
(6, 'gf', '$2y$10$8VFKNW8W2ZIfMFUiXx4/2OLtRlutkqKpnKTk8m7BKJ5mpDXmO13ay', 'asfa@gmail.com', 8, 'female', '2024-12-21 04:35:13', '2024-12-21 04:35:13', NULL, NULL),
(7, 'manoj', '$2y$10$ST0XRt/6GPpTfM7d5EGEr.jSA5rbPyXTwPBpPL34JA7ADuaxTJcUi', 'manoj@gmail.com', 5, 'male', '2024-12-26 06:01:31', '2024-12-26 06:01:31', NULL, NULL),
(8, 'nishitha', '$2y$10$sOnEZOJnOmLmEcRQqr6fcOsJcJ0YDDrKcozMhIugV3gV1fbsGO8Hi', 'nishitha@gmail.com', 1, 'male', '2024-12-27 05:28:43', '2024-12-27 05:28:43', NULL, NULL),
(9, 'dhano', '$2y$10$Wb1OkkShSxQCSmRcz9Xiae//p5a3nMhOvED.4WSmksDjrMauThYWC', 'dhano@gmail.com', 5, 'female', '2025-01-03 02:33:19', '2025-01-03 02:33:19', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_logs`
--

CREATE TABLE `user_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_logs`
--

INSERT INTO `user_logs` (`id`, `user_id`, `is_active`, `created_at`, `updated_at`) VALUES
(21, 9, 1, '2025-01-06 05:24:31', '2025-01-06 05:24:31'),
(24, 3, 1, '2025-01-06 07:06:49', '2025-01-06 07:06:49');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chat_wit_friends`
--
ALTER TABLE `chat_wit_friends`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `user_logs`
--
ALTER TABLE `user_logs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chat_wit_friends`
--
ALTER TABLE `chat_wit_friends`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user_logs`
--
ALTER TABLE `user_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
