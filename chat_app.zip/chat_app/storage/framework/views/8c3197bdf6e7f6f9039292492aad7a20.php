<?php $__env->startSection('title','Chat Application - User Dashboard'); ?>
<?php $__env->startSection('main-content'); ?>
<?php echo $__env->make('layout.user_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="dashboard-content">
    <div class="container">
        <div class="row">
            <div class="col-md-4"></div>
            <div class="col-md-4">
                <form method="post" action="<?php echo e(route('user.friend_search')); ?>" autocomplete="off">
                <?php echo csrf_field(); ?>
                <div class="input-group input-group-lg mt-3">
                    <input type="text" class="form-control" name="name" id="name" value="<?php echo e(old('name')); ?>" placeholder="Search Friends">
                    <button class="btn btn-success" type="submit">Search</button>
                </div>
                    <?php if($errors->has('name')): ?>
                    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                    <?php endif; ?>
                </form>
            <div class="mt-3">
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mb-3">
                    <img src="<?php echo e(asset('assets/images/'.$user->gender.'.png')); ?>" style="height:280px;" class="card-img-top rounded">
                    <div class="card-body text-center">
                        <h2><?php echo e($user->name); ?></hs>
                        <h5><?php echo e($user->country_name); ?></h5>
                        <p><?php echo e($user->gender); ?></p>

                    <form method="post" action="<?php echo e(route('user.add_friend')); ?>" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="friend_id" value="<?php echo e($user->uid); ?>" id="friend_id">
                    <div class="d-grid">
                    <button type="submit" class="btn btn-success d-block">Chat With <?php echo e($user->name); ?></button>
                        </div>
                    </form>
                    </div>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            </div>
            </div>
            <div class="col-md-4"></div>

       </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ganesh\pros\chat_app\resources\views/user/dashboard.blade.php ENDPATH**/ ?>