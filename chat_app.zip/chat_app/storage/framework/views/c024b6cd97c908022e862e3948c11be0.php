<?php $__env->startSection('title','Chat Application - Update Password'); ?>
<?php $__env->startSection('main-content'); ?>
<?php echo $__env->make('layout.user_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="dashboard-content">
<div class="container">
    <?php echo $__env->make('layout.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card my-2">
        <div class="card-header">
            <h3 class="text-center">Change Password</h3>
        </div>
        <div class="card-body">
            <form method="post" action="<?php echo e(route('user.update_password')); ?>" autocomplete="off">
                <?php echo csrf_field(); ?>
            <table class="table table-bordered">
                <tr>
                    <th>Current Password</th>
                    <td>
                        <input type="password" class="form-control"  name="current_password" placeholder="Enter Current Password" id="current_password">
                        <?php if($errors->has('current_password')): ?>
                        <span class="text-danger"><?php echo e($errors->first('current_password')); ?></span>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th>New Password</th>
                    <td>
                        <input type="password" class="form-control"  name="new_password" placeholder="Enter New Password" id="new_password">
                        <?php if($errors->has('new_password')): ?>
                        <span class="text-danger"><?php echo e($errors->first('new_password')); ?></span>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th>Confirm Password</th>
                    <td>
                        <input type="password" class="form-control"  name="confirm_password" placeholder="Enter Confirm Password" id="confirm_password">
                        <?php if($errors->has('confirm_password')): ?>
                        <span class="text-danger"><?php echo e($errors->first('confirm_password')); ?></span>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" align="center">
                        <input type="submit" name="update" id="update" class="btn btn-primary px-4 py-2" value="Update">
                    </td>
                </tr>
            </table>
            </form>
        </div>



    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ganesh\pros\chat_app\resources\views/user/change_password.blade.php ENDPATH**/ ?>