<?php if(session('success')): ?>
<div class="alert alert-success alert-dismissible">
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    <strong>Success!</strong> <?php echo e(session('success')); ?>

  </div>
<?php endif; ?>
<?php if(session('error')): ?>
<div class="alert alert-danger alert-dismissible">
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    <strong>Error!</strong> <?php echo e(session('error')); ?>

  </div>
<?php endif; ?>
<?php /**PATH D:\Ganesh\pros\chat_app\resources\views/layout/alert.blade.php ENDPATH**/ ?>