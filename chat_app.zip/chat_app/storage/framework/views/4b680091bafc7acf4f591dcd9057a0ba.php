<?php $__env->startSection('title','Chat Application - Home Page'); ?>
<?php $__env->startSection('main-content'); ?>
<div class="home-content bg-content1">
    <div class="container">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">

               <?php echo $__env->make('layout.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card my-3">
            <div class="card-header thick-green">
                <h4 class="text-white text-center  fst-italic">Welcome to Chatting Application</h4>
                <p class="text-white text-center">Sign Up to Chat with Others</p>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('main.signup')); ?>" autocomplete="off" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3 mt-3">
                      <label for="name" class="form-label">Username:</label>
                      <input type="text" class="form-control" id="name" placeholder="Enter username" value="<?php echo e(old('name')); ?>" name="name">

                      <?php if($errors->has('name')): ?>
                      <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                      <?php endif; ?>
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label">Password:</label>
                        <input type="password" class="form-control" id="password" placeholder="Enter password" value="<?php echo e(old('password')); ?>" name="password">

                      <?php if($errors->has('password')): ?>
                      <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                      <?php endif; ?>
                      </div>
                    <div class="mb-3 mt-3">
                        <label for="email" class="form-label">Email:</label>
                        <input type="text" class="form-control" id="email" placeholder="Enter email" value="<?php echo e(old('email')); ?>" name="email">

                      <?php if($errors->has('email')): ?>
                      <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                      <?php endif; ?>
                      </div>
                      <div class="mb-3 mt-3">
                        <label for="country" class="form-label">Country:</label>
                        <select class="form-select" name="country" id="country">
                            <option value="">Choose Country</option>
                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($country->id); ?>" <?php echo e(old('country')==$country->id ? 'selected' : ''); ?>><?php echo e($country->country_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>

                      <?php if($errors->has('country')): ?>
                      <span class="text-danger"><?php echo e($errors->first('country')); ?></span>
                      <?php endif; ?>
                      </div>
                      <div class="mb-3 mt-3">
                        <label for="gender" class="form-label">Gender:</label>
                        <select class="form-select" name="gender" id="gender">
                            <option value="">Choose Gender</option>
                            <option value="male" <?php echo e(old('gender')=='male' ? 'selected' : ''); ?>>Male</option>
                            <option value="female" <?php echo e(old('gender')=='female' ? 'selected' : ''); ?>>Female</option>
                          </select>

                      <?php if($errors->has('gender')): ?>
                      <span class="text-danger"><?php echo e($errors->first('gender')); ?></span>
                      <?php endif; ?>
                      </div>
                    <div class="form-check mb-3">
                      <label class="form-check-label">
                        <input class="form-check-input" type="checkbox" name="remember" value="Y" <?php echo e(old('remember')=='Y' ? 'checked' : ''); ?>> I accept the <b class="text-green">Terms of Use</b> & <b  class="text-green">privacy Policy</b>
                      </label>
                      <?php if($errors->has('remember')): ?>
                      <br/><span class="text-danger"><?php echo e($errors->first('remember')); ?></span>
                      <?php endif; ?>
                    </div>
                    <div class="d-grid">
                        <button type="submit" class="btn thick-green btn-block text-white">Sign Up</button>
                    </div>
                  </form>
            </div>
            <p class="text-center fw-bold">Already have an Account ? <a href="<?php echo e(route('main.login')); ?>" class="text-green text-decoration-none">Sign in here</a></p>
        </div>

    </div>
</div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ganesh\pros\chat_app\resources\views/home.blade.php ENDPATH**/ ?>