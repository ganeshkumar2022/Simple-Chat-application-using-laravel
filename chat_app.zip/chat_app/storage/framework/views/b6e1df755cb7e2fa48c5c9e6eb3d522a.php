<?php $__env->startSection('title','Chat Application - Chat page'); ?>
<?php $__env->startSection('main-content'); ?>
<div class="dashboard-content w-100 overflow-hidden">
    <div class="row bg-dark">
        <div class="col-md-3 py-3 border border-light">
            <center>
                <a href="<?php echo e(route('user.dashboard')); ?>" class="btn btn-outline-light">Add New User</a>
            </center>
        </div>
        <div class="col-md-9 border py-3 border-light">
            <?php if($chat_with): ?>
            <table>
                <tr>
                    <td>
                        <?php if($chat_with->profile_image==null): ?>
                        <img src="<?php echo e(asset('assets/images/'.$chat_with->gender.'.png')); ?>" style="height:50px;width:50px;" class="rounded-circle">
                        <?php else: ?>
                        <img src="<?php echo e(asset('profile_images/'.$chat_with->profile_image)); ?>" style="height:50px;width:50px;" class="rounded-circle">
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="ms-3">
                        <span class="text-primary"><?php echo e($chat_with->name); ?></span> <br/>
                        <span class="text-secondary small">0 messages </span>
                        <a href="<?php echo e(route('user.logout')); ?>" class="btn btn-danger ms-3">Logout</a>
                        </div>
                    </td>
                </tr>
            </table>

            <?php endif; ?>
        </div>
    </div>
    <div class="row">
        <div class="col-md-3 bg-dark py-3 border border-light" style="height:90vh;overflow-x:hidden;overflow-y:scroll;">
            <table class="table-dark table-borderless table">
                <?php $__currentLoopData = $friends_get; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $friends): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="p-2">
                    <td width="12%;">

                <a href="<?php echo e(route('user.chats',$friends->id)); ?>" class="text-decoration-none">
                        <?php if($friends->profile_image==null): ?>
                        <img src="<?php echo e(asset('assets/images/'.$friends->gender.'.png')); ?>" style="height:50px;width:50px;" class="rounded-circle">
                        <?php else: ?>
                        <img src="<?php echo e(asset('profile_images/'.$friends->profile_image)); ?>" style="height:50px;width:50px;" class="rounded-circle">
                        <?php endif; ?>
                    </a>
                    </td>
                    <td>

                        <a href="<?php echo e(route('user.chats',$friends->id)); ?>" class="text-decoration-none">
                                <span class="text-primary"><?php echo e($friends->name); ?></span> <br/>
                                <?php if($friends->is_active==1): ?>
                                    <span class="text-success small"><i class="fa-solid fa-circle-dot"></i> Online </span>
                                <?php else: ?>
                                    <span class="text-secondary small"><i class="fa-solid fa-circle-dot"></i> Offline </span>
                                <?php endif; ?>
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
        <div class="col-md-9 border py-3 border-light position-relative" style="height:90vh;overflow-x:hidden;overflow-y:scroll;">
            <!-- messages display start -->
            <?php if($chat_with): ?>
            <div class="row">
            <?php $__currentLoopData = $my_messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mymessage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($mymessage->from_id==$iam->id): ?>
                <div class="col-md-6 offset-6">
                <span class="text-end"><b><?php echo e($iam->name); ?></b> <?php echo e($mymessage->created_at); ?></span>
                <div class="card mb-2" style="background-color:rgb(154, 206, 235);">
                    <div class="card-body">
                        <?php echo e($mymessage->message); ?>

                    </div>
                </div>
                </div>
            <?php else: ?>
                <div class="col-md-6">
                    <span class="text-start"><b><?php echo e($chat_with->name); ?></b> <?php echo e($mymessage->created_at); ?></span>
                <div class="card mb-2" style="background-color:rgb(175, 225, 175);">
                    <div class="card-body">
                        <?php echo e($mymessage->message); ?>

                    </div>
                </div>
                </div>
                <div class="col-md-4"></div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!-- messages display end -->
            <div class="">
                 <form action="<?php echo e(route('user.send_message')); ?>" method="post" autocomplete="off">
                <div class="row bg-dark py-3 position-absolute fixed-bottom">
                    <div class="col-md-10">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="receiver_id" value="<?php echo e($chat_with->id); ?>">
                        <input type="text" class="form-control ms-3" id="message" placeholder="Write your Message" name="message">
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn border ms-3 bg-white"><i class="fa-solid fa-paper-plane"></i></button>
                    </div>
                </form>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ganesh\pros\chat_app\resources\views/user/chat_page.blade.php ENDPATH**/ ?>