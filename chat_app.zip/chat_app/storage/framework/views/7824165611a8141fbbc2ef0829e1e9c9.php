<?php $__env->startSection('title','Chat Application - Forget password'); ?>
<?php $__env->startSection('main-content'); ?>
<div class="home-content bg-content1">
    <div class="container">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
               <?php echo $__env->make('layout.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card my-3">
            <div class="card-header thick-green">
                <h4 class="text-white text-center fst-italic">Forget Password</h4>
                <p class="text-white text-center">My Chat</p>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('main.submit_forgot_password')); ?>" autocomplete="off" method="post">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3 mt-3">
                        <label for="email" class="form-label">Email:</label>
                        <input type="text" class="form-control" id="email" placeholder="Enter email" value="<?php echo e(old('email')); ?>" name="email">

                      <?php if($errors->has('email')): ?>
                      <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                      <?php endif; ?>
                      </div>
                    <div class="mb-3">
                        <label for="friend_name" class="form-label">Best Friend Name:</label>
                        <input type="text" class="form-control" id="friend_name" placeholder="Enter Friend name" value="<?php echo e(old('friend_name')); ?>" name="friend_name">

                      <?php if($errors->has('friend_name')): ?>
                      <span class="text-danger"><?php echo e($errors->first('friend_name')); ?></span>
                      <?php endif; ?>
                      </div>

                    <div class="d-grid">
                        <button type="submit" class="btn thick-green btn-block text-white">Submit</button>
                    </div>
                  </form>
                  <div class="mb-2">
                    <span>Back to Signin ?</span> <a href="<?php echo e(route('main.login')); ?>" class="text-green text-decoration-none">Click Here</a>
                </div>
            </div>
        </div>

    </div>
</div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ganesh\pros\chat_app\resources\views/forgot_password.blade.php ENDPATH**/ ?>