<?php $__env->startSection('title','Chat Application - Login Page'); ?>
<?php $__env->startSection('main-content'); ?>
<div class="home-content bg-content1">
    <div class="container">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
               <?php echo $__env->make('layout.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card my-3">
            <div class="card-header thick-green">
                <h4 class="text-white text-center fst-italic">Sign in Chatting Application</h4>
                <p class="text-white text-center">Login to your Account</p>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('main.verify_login')); ?>" autocomplete="off" method="post">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3 mt-3">
                        <label for="email" class="form-label">Email:</label>
                        <input type="text" class="form-control" id="email" placeholder="Enter email" value="<?php echo e(old('email')); ?>" name="email">

                      <?php if($errors->has('email')): ?>
                      <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                      <?php endif; ?>
                      </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password:</label>
                        <input type="password" class="form-control" id="password" placeholder="Enter password" value="<?php echo e(old('password')); ?>" name="password">

                      <?php if($errors->has('password')): ?>
                      <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                      <?php endif; ?>
                      </div>

                    <div class="mb-2">
                        <span>Forgotten Password ?</span> <a href="<?php echo e(route('main.forgot_password')); ?>" class="text-green text-decoration-none">Click Here</a>
                    </div>
                    <div class="d-grid">
                        <button type="submit" class="btn thick-green btn-block text-white">Sign In</button>
                    </div>
                  </form>
            </div>
            <p class="text-center fw-bold">Don't have an Account ? <a href="<?php echo e(route('main.home')); ?>" class="text-green text-decoration-none">Create here</a></p>
        </div>

    </div>
</div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ganesh\pros\chat_app\resources\views/login.blade.php ENDPATH**/ ?>