<?php $__env->startSection('title','Chat Application - Settings page'); ?>
<?php $__env->startSection('main-content'); ?>
<?php echo $__env->make('layout.user_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="dashboard-content">
<div class="container">
    <?php echo $__env->make('layout.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card my-2">
        <div class="card-header">
            <h3 class="text-center">Change Account Settings</h3>
        </div>
        <div class="card-body">
            <form method="post" action="<?php echo e(route('user.user_data_update')); ?>" autocomplete="off">
                <?php echo csrf_field(); ?>
            <table class="table table-bordered">
                <tr>
                    <th>Change your Username</th>
                    <td>
                        <input type="text" class="form-control" value="<?php echo e($user->name); ?>" name="name" id="name">
                        <?php if($errors->has('name')): ?>
                        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th></th>
                    <td>
                        <a href="<?php echo e(route('user.profile')); ?>" class="text-decoration-none"><i class="fa-solid fa-user"></i> Change Profile</a>
                    </td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td>
                        <input type="text" class="form-control" name="email" value="<?php echo e($user->email); ?>" id="email">
                        <?php if($errors->has('email')): ?>
                        <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th>Country</th>
                    <td>
                        <select class="form-select" name="country" id="country">
                            <option value="">Choose Country</option>
                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($country->id); ?>" <?php echo e($country->id==$user->country ? 'selected' : ''); ?>><?php echo e($country->country_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                          <?php if($errors->has('country')): ?>
                          <span class="text-danger"><?php echo e($errors->first('country')); ?></span>
                          <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th>Gender</th>
                    <td>
                        <select class="form-select" name="gender" id="gender">
                            <option value="">Choose Gender</option>
                            <option value="male" <?php echo e($user->gender=="male" ? 'selected' : ''); ?>>Male</option>
                            <option value="female" <?php echo e($user->gender=="female" ? 'selected' : ''); ?>>Female</option>
                          </select>
                          <?php if($errors->has('gender')): ?>
                          <span class="text-danger"><?php echo e($errors->first('gender')); ?></span>
                          <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th>Forgetten Password</th>
                    <td>
                        <a href="" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#forgot_pass">Forgotten Password</a>
                    </td>
                </tr>
                <tr>
                    <th></th>
                    <td>
                        <a href="<?php echo e(route('user.change_password')); ?>" class="text-decoration-none"><i class="fa-solid fa-key"></i> Change Password</a>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" align="center">
                        <input type="submit" name="update" id="update" class="btn btn-primary px-4 py-2" value="Update">
                    </td>
                </tr>
            </table>
            </form>
        </div>

        <!-- The Modal -->
<div class="modal fade" id="forgot_pass">
    <div class="modal-dialog">
      <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
          <form method="post" action="<?php echo e(route('user.security_question')); ?>" autocomplete="off">
            <?php echo csrf_field(); ?>
          <h5>What is your School Best Friend Name</h5>
          <textarea class="form-control" name="friend_name" value="<?php echo e(old('friend_name')); ?>"  id="friend_name" rows="5" placeholder="Enter your Friend Name"><?php echo e($user->security_question); ?></textarea>
          <?php if($errors->has('friend_name')): ?>
          <span class="text-danger"><?php echo e($errors->first('friend_name')); ?></span>
          <?php endif; ?>
          <div>
          <input type="submit" name="submit" id="submit" class="btn btn-primary mt-2" value="Submit">
        </div>
        </form>
        <span class="text-danger fw-bold">(Answer the above question we will ask you ths question you forget the password )</span>
        </div>

        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
        </div>

      </div>
    </div>
  </div>
<?php if($errors->has('friend_name')): ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
    var myModal = new bootstrap.Modal(document.getElementById('forgot_pass'));
    myModal.show();
  });
</script>
<?php endif; ?>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ganesh\pros\chat_app\resources\views/user/settings.blade.php ENDPATH**/ ?>