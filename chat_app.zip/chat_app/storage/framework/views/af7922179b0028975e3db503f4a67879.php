<nav class="navbar navbar-expand-sm bg-success navbar-dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">User Panel</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav">
          <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('user.dashboard')); ?>">Add Friend</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('user.chats')); ?>">Chat with Friends</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('user.settings')); ?>">Settings</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('user.logout')); ?>">Logout</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
<?php /**PATH D:\Ganesh\pros\chat_app\resources\views/layout/user_header.blade.php ENDPATH**/ ?>