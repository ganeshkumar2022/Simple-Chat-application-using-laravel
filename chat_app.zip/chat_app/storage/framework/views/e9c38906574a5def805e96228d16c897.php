<?php $__env->startSection('title','Chat Application - Profile page'); ?>
<?php $__env->startSection('main-content'); ?>
<?php echo $__env->make('layout.user_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="dashboard-content">
<div class="container">
    <?php echo $__env->make('layout.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card my-2">
        <div class="card-header">
            <h3 class="text-center">Update Profile</h3>
        </div>
        <div class="card-body">
            <form method="post" action="<?php echo e(route('user.update_profile')); ?>" autocomplete="off" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div>
                    <center>
                    <?php if($user->gender=="male"): ?>
                      <?php if($user->profile_image==null): ?>
                        <img src="<?php echo e(asset('assets/images/male.png')); ?>" style="height:200px;width:200px;">
                      <?php else: ?>
                         <img src="<?php echo e(asset('profile_images/'.$user->profile_image)); ?>" style="height:200px;width:200px;">
                      <?php endif; ?>
                    <?php elseif($user->gender=="female"): ?>
                        <?php if($user->profile_image==null): ?>
                            <img src="<?php echo e(asset('assets/images/female.png')); ?>" style="height:200px;width:200px;">
                        <?php else: ?>
                            <img src="<?php echo e(asset('profile_images/'.$user->profile_image)); ?>" style="height:200px;width:200px;">
                        <?php endif; ?>
                    <?php endif; ?>
                </center>
                </div>
            <table class="table table-bordered">
                <tr>
                    <th>Profile Image</th>
                    <td>
                        <input type="file" class="form-control" name="profile_image" id="profile_image">
                        <?php if($errors->has('profile_image')): ?>
                        <span class="text-danger"><?php echo e($errors->first('profile_image')); ?></span>
                        <?php endif; ?>
                    </td>
                </tr>

                <tr>
                    <td colspan="2" align="center">
                        <input type="submit" name="update" id="update" class="btn btn-primary px-4 py-2" value="Update">
                    </td>
                </tr>
            </table>
            </form>
        </div>
    </div>
    
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ganesh\pros\chat_app\resources\views/user/profile.blade.php ENDPATH**/ ?>