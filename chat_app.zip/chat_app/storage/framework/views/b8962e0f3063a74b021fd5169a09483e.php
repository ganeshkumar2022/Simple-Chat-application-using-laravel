<?php $__env->startSection('title','Chat Application - Login Page'); ?>
<?php $__env->startSection('main-content'); ?>
<div class="home-content bg-content1">
    <div class="container">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
               <?php echo $__env->make('layout.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card my-3">
            <div class="card-header thick-green">
                <h4 class="text-white text-center fst-italic">Create New Password</h4>
                <p class="text-white text-center">My Chat</p>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('main.new_password_change')); ?>" autocomplete="off" method="post">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3 mt-3">
                        <label for="new_password" class="form-label">New Password:</label>
                        <input type="password" class="form-control" id="new_password" placeholder="Enter new password" value="<?php echo e(old('new_password')); ?>" name="new_password">

                      <?php if($errors->has('new_password')): ?>
                      <span class="text-danger"><?php echo e($errors->first('new_password')); ?></span>
                      <?php endif; ?>
                      </div>
                    <div class="mb-3">
                        <label for="confirm_password" class="form-label">Confirm Password:</label>
                        <input type="password" class="form-control" id="confirm_password" placeholder="Enter confirm password" value="<?php echo e(old('confirm_password')); ?>" name="confirm_password">

                      <?php if($errors->has('confirm_password')): ?>
                      <span class="text-danger"><?php echo e($errors->first('confirm_password')); ?></span>
                      <?php endif; ?>
                      </div>

                    <div class="d-grid">
                        <button type="submit" class="btn thick-green btn-block text-white">Change Password</button>
                    </div>
                  </form>
            </div>
            <p class="text-center fw-bold">Back to Login ? <a href="<?php echo e(route('main.login')); ?>" class="text-green text-decoration-none">Click Here</a></p>
        </div>

    </div>
</div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ganesh\pros\chat_app\resources\views/create_new_password.blade.php ENDPATH**/ ?>