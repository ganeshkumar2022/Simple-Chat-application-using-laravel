@extends('layout.master')
@section('title','Chat Application - Login Page')
@section('main-content')
<div class="home-content bg-content1">
    <div class="container">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
               @include('layout.alert')
        <div class="card my-3">
            <div class="card-header thick-green">
                <h4 class="text-white text-center fst-italic">Sign in Chatting Application</h4>
                <p class="text-white text-center">Login to your Account</p>
            </div>
            <div class="card-body">
                <form action="{{ route('main.verify_login') }}" autocomplete="off" method="post">
                    @csrf

                    <div class="mb-3 mt-3">
                        <label for="email" class="form-label">Email:</label>
                        <input type="text" class="form-control" id="email" placeholder="Enter email" value="{{ old('email') }}" name="email">

                      @if($errors->has('email'))
                      <span class="text-danger">{{ $errors->first('email') }}</span>
                      @endif
                      </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password:</label>
                        <input type="password" class="form-control" id="password" placeholder="Enter password" value="{{ old('password') }}" name="password">

                      @if($errors->has('password'))
                      <span class="text-danger">{{ $errors->first('password') }}</span>
                      @endif
                      </div>

                    <div class="mb-2">
                        <span>Forgotten Password ?</span> <a href="{{ route('main.forgot_password') }}" class="text-green text-decoration-none">Click Here</a>
                    </div>
                    <div class="d-grid">
                        <button type="submit" class="btn thick-green btn-block text-white">Sign In</button>
                    </div>
                  </form>
            </div>
            <p class="text-center fw-bold">Don't have an Account ? <a href="{{ route('main.home') }}" class="text-green text-decoration-none">Create here</a></p>
        </div>

    </div>
</div>
    </div>
</div>
@endsection
