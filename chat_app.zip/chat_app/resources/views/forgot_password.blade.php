@extends('layout.master')
@section('title','Chat Application - Forget password')
@section('main-content')
<div class="home-content bg-content1">
    <div class="container">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
               @include('layout.alert')
        <div class="card my-3">
            <div class="card-header thick-green">
                <h4 class="text-white text-center fst-italic">Forget Password</h4>
                <p class="text-white text-center">My Chat</p>
            </div>
            <div class="card-body">
                <form action="{{ route('main.submit_forgot_password') }}" autocomplete="off" method="post">
                    @csrf

                    <div class="mb-3 mt-3">
                        <label for="email" class="form-label">Email:</label>
                        <input type="text" class="form-control" id="email" placeholder="Enter email" value="{{ old('email') }}" name="email">

                      @if($errors->has('email'))
                      <span class="text-danger">{{ $errors->first('email') }}</span>
                      @endif
                      </div>
                    <div class="mb-3">
                        <label for="friend_name" class="form-label">Best Friend Name:</label>
                        <input type="text" class="form-control" id="friend_name" placeholder="Enter Friend name" value="{{ old('friend_name') }}" name="friend_name">

                      @if($errors->has('friend_name'))
                      <span class="text-danger">{{ $errors->first('friend_name') }}</span>
                      @endif
                      </div>

                    <div class="d-grid">
                        <button type="submit" class="btn thick-green btn-block text-white">Submit</button>
                    </div>
                  </form>
                  <div class="mb-2">
                    <span>Back to Signin ?</span> <a href="{{ route('main.login') }}" class="text-green text-decoration-none">Click Here</a>
                </div>
            </div>
        </div>

    </div>
</div>
    </div>
</div>
@endsection
