@extends('layout.master')
@section('title','Chat Application - Home Page')
@section('main-content')
<div class="home-content bg-content1">
    <div class="container">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">

               @include('layout.alert')
        <div class="card my-3">
            <div class="card-header thick-green">
                <h4 class="text-white text-center  fst-italic">Welcome to Chatting Application</h4>
                <p class="text-white text-center">Sign Up to Chat with Others</p>
            </div>
            <div class="card-body">
                <form action="{{ route('main.signup') }}" autocomplete="off" method="post">
                    @csrf
                    <div class="mb-3 mt-3">
                      <label for="name" class="form-label">Username:</label>
                      <input type="text" class="form-control" id="name" placeholder="Enter username" value="{{ old('name') }}" name="name">

                      @if($errors->has('name'))
                      <span class="text-danger">{{ $errors->first('name') }}</span>
                      @endif
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label">Password:</label>
                        <input type="password" class="form-control" id="password" placeholder="Enter password" value="{{ old('password') }}" name="password">

                      @if($errors->has('password'))
                      <span class="text-danger">{{ $errors->first('password') }}</span>
                      @endif
                      </div>
                    <div class="mb-3 mt-3">
                        <label for="email" class="form-label">Email:</label>
                        <input type="text" class="form-control" id="email" placeholder="Enter email" value="{{ old('email') }}" name="email">

                      @if($errors->has('email'))
                      <span class="text-danger">{{ $errors->first('email') }}</span>
                      @endif
                      </div>
                      <div class="mb-3 mt-3">
                        <label for="country" class="form-label">Country:</label>
                        <select class="form-select" name="country" id="country">
                            <option value="">Choose Country</option>
                            @foreach ($countries as $country)
                                <option value="{{ $country->id }}" {{ old('country')==$country->id ? 'selected' : '' }}>{{ $country->country_name }}</option>
                            @endforeach
                          </select>

                      @if($errors->has('country'))
                      <span class="text-danger">{{ $errors->first('country') }}</span>
                      @endif
                      </div>
                      <div class="mb-3 mt-3">
                        <label for="gender" class="form-label">Gender:</label>
                        <select class="form-select" name="gender" id="gender">
                            <option value="">Choose Gender</option>
                            <option value="male" {{ old('gender')=='male' ? 'selected' : '' }}>Male</option>
                            <option value="female" {{ old('gender')=='female' ? 'selected' : '' }}>Female</option>
                          </select>

                      @if($errors->has('gender'))
                      <span class="text-danger">{{ $errors->first('gender') }}</span>
                      @endif
                      </div>
                    <div class="form-check mb-3">
                      <label class="form-check-label">
                        <input class="form-check-input" type="checkbox" name="remember" value="Y" {{ old('remember')=='Y' ? 'checked' : '' }}> I accept the <b class="text-green">Terms of Use</b> & <b  class="text-green">privacy Policy</b>
                      </label>
                      @if($errors->has('remember'))
                      <br/><span class="text-danger">{{ $errors->first('remember') }}</span>
                      @endif
                    </div>
                    <div class="d-grid">
                        <button type="submit" class="btn thick-green btn-block text-white">Sign Up</button>
                    </div>
                  </form>
            </div>
            <p class="text-center fw-bold">Already have an Account ? <a href="{{ route('main.login') }}" class="text-green text-decoration-none">Sign in here</a></p>
        </div>

    </div>
</div>
    </div>
</div>
@endsection
