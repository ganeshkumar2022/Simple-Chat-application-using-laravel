@extends('layout.master')
@section('title','Chat Application - Update Password')
@section('main-content')
@include('layout.user_header')
<div class="dashboard-content">
<div class="container">
    @include('layout.alert')
    <div class="card my-2">
        <div class="card-header">
            <h3 class="text-center">Change Password</h3>
        </div>
        <div class="card-body">
            <form method="post" action="{{ route('user.update_password') }}" autocomplete="off">
                @csrf
            <table class="table table-bordered">
                <tr>
                    <th>Current Password</th>
                    <td>
                        <input type="password" class="form-control"  name="current_password" placeholder="Enter Current Password" id="current_password">
                        @if($errors->has('current_password'))
                        <span class="text-danger">{{$errors->first('current_password')}}</span>
                        @endif
                    </td>
                </tr>
                <tr>
                    <th>New Password</th>
                    <td>
                        <input type="password" class="form-control"  name="new_password" placeholder="Enter New Password" id="new_password">
                        @if($errors->has('new_password'))
                        <span class="text-danger">{{$errors->first('new_password')}}</span>
                        @endif
                    </td>
                </tr>
                <tr>
                    <th>Confirm Password</th>
                    <td>
                        <input type="password" class="form-control"  name="confirm_password" placeholder="Enter Confirm Password" id="confirm_password">
                        @if($errors->has('confirm_password'))
                        <span class="text-danger">{{$errors->first('confirm_password')}}</span>
                        @endif
                    </td>
                </tr>
                <tr>
                    <td colspan="2" align="center">
                        <input type="submit" name="update" id="update" class="btn btn-primary px-4 py-2" value="Update">
                    </td>
                </tr>
            </table>
            </form>
        </div>



    </div>
</div>
</div>
@endsection
