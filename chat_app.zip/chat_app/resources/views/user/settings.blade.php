@extends('layout.master')
@section('title','Chat Application - Settings page')
@section('main-content')
@include('layout.user_header')
<div class="dashboard-content">
<div class="container">
    @include('layout.alert')
    <div class="card my-2">
        <div class="card-header">
            <h3 class="text-center">Change Account Settings</h3>
        </div>
        <div class="card-body">
            <form method="post" action="{{ route('user.user_data_update') }}" autocomplete="off">
                @csrf
            <table class="table table-bordered">
                <tr>
                    <th>Change your Username</th>
                    <td>
                        <input type="text" class="form-control" value="{{ $user->name }}" name="name" id="name">
                        @if($errors->has('name'))
                        <span class="text-danger">{{$errors->first('name')}}</span>
                        @endif
                    </td>
                </tr>
                <tr>
                    <th></th>
                    <td>
                        <a href="{{ route('user.profile') }}" class="text-decoration-none"><i class="fa-solid fa-user"></i> Change Profile</a>
                    </td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td>
                        <input type="text" class="form-control" name="email" value="{{ $user->email }}" id="email">
                        @if($errors->has('email'))
                        <span class="text-danger">{{$errors->first('email')}}</span>
                        @endif
                    </td>
                </tr>
                <tr>
                    <th>Country</th>
                    <td>
                        <select class="form-select" name="country" id="country">
                            <option value="">Choose Country</option>
                            @foreach ($countries as $country)
                                <option value="{{ $country->id }}" {{ $country->id==$user->country ? 'selected' : '' }}>{{ $country->country_name }}</option>
                            @endforeach
                          </select>
                          @if($errors->has('country'))
                          <span class="text-danger">{{$errors->first('country')}}</span>
                          @endif
                    </td>
                </tr>
                <tr>
                    <th>Gender</th>
                    <td>
                        <select class="form-select" name="gender" id="gender">
                            <option value="">Choose Gender</option>
                            <option value="male" {{ $user->gender=="male" ? 'selected' : '' }}>Male</option>
                            <option value="female" {{ $user->gender=="female" ? 'selected' : '' }}>Female</option>
                          </select>
                          @if($errors->has('gender'))
                          <span class="text-danger">{{$errors->first('gender')}}</span>
                          @endif
                    </td>
                </tr>
                <tr>
                    <th>Forgetten Password</th>
                    <td>
                        <a href="" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#forgot_pass">Forgotten Password</a>
                    </td>
                </tr>
                <tr>
                    <th></th>
                    <td>
                        <a href="{{ route('user.change_password') }}" class="text-decoration-none"><i class="fa-solid fa-key"></i> Change Password</a>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" align="center">
                        <input type="submit" name="update" id="update" class="btn btn-primary px-4 py-2" value="Update">
                    </td>
                </tr>
            </table>
            </form>
        </div>

        <!-- The Modal -->
<div class="modal fade" id="forgot_pass">
    <div class="modal-dialog">
      <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
          <form method="post" action="{{ route('user.security_question') }}" autocomplete="off">
            @csrf
          <h5>What is your School Best Friend Name</h5>
          <textarea class="form-control" name="friend_name" value="{{ old('friend_name') }}"  id="friend_name" rows="5" placeholder="Enter your Friend Name">{{ $user->security_question }}</textarea>
          @if($errors->has('friend_name'))
          <span class="text-danger">{{ $errors->first('friend_name') }}</span>
          @endif
          <div>
          <input type="submit" name="submit" id="submit" class="btn btn-primary mt-2" value="Submit">
        </div>
        </form>
        <span class="text-danger fw-bold">(Answer the above question we will ask you ths question you forget the password )</span>
        </div>

        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
        </div>

      </div>
    </div>
  </div>
@if($errors->has('friend_name'))
<script>
    document.addEventListener('DOMContentLoaded', function () {
    var myModal = new bootstrap.Modal(document.getElementById('forgot_pass'));
    myModal.show();
  });
</script>
@endif
    </div>
</div>
</div>
@endsection
