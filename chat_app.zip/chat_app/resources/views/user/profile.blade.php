@extends('layout.master')
@section('title','Chat Application - Profile page')
@section('main-content')
@include('layout.user_header')
<div class="dashboard-content">
<div class="container">
    @include('layout.alert')
    <div class="card my-2">
        <div class="card-header">
            <h3 class="text-center">Update Profile</h3>
        </div>
        <div class="card-body">
            <form method="post" action="{{ route('user.update_profile') }}" autocomplete="off" enctype="multipart/form-data">
                @csrf
                <div>
                    <center>
                    @if($user->gender=="male")
                      @if($user->profile_image==null)
                        <img src="{{ asset('assets/images/male.png') }}" style="height:200px;width:200px;">
                      @else
                         <img src="{{ asset('profile_images/'.$user->profile_image) }}" style="height:200px;width:200px;">
                      @endif
                    @elseif ($user->gender=="female")
                        @if($user->profile_image==null)
                            <img src="{{ asset('assets/images/female.png') }}" style="height:200px;width:200px;">
                        @else
                            <img src="{{ asset('profile_images/'.$user->profile_image) }}" style="height:200px;width:200px;">
                        @endif
                    @endif
                </center>
                </div>
            <table class="table table-bordered">
                <tr>
                    <th>Profile Image</th>
                    <td>
                        <input type="file" class="form-control" name="profile_image" id="profile_image">
                        @if($errors->has('profile_image'))
                        <span class="text-danger">{{$errors->first('profile_image')}}</span>
                        @endif
                    </td>
                </tr>

                <tr>
                    <td colspan="2" align="center">
                        <input type="submit" name="update" id="update" class="btn btn-primary px-4 py-2" value="Update">
                    </td>
                </tr>
            </table>
            </form>
        </div>
    </div>
    
</div>
</div>
@endsection
