@extends('layout.master')
@section('title','Chat Application - User Dashboard')
@section('main-content')
@include('layout.user_header')
@include('layout.alert')
<div class="dashboard-content">
    <div class="container">
        <div class="row">
            <div class="col-md-4"></div>
            <div class="col-md-4">
                <form method="post" action="{{ route('user.friend_search') }}" autocomplete="off">
                @csrf
                <div class="input-group input-group-lg mt-3">
                    <input type="text" class="form-control" name="name" id="name" value="{{ old('name') }}" placeholder="Search Friends">
                    <button class="btn btn-success" type="submit">Search</button>
                </div>
                    @if($errors->has('name'))
                    <span class="text-danger">{{ $errors->first('name') }}</span>
                    @endif
                </form>
            <div class="mt-3">
                @foreach ($users as $user)
                <div class="card mb-3">
                    <img src="{{ asset('assets/images/'.$user->gender.'.png') }}" style="height:280px;" class="card-img-top rounded">
                    <div class="card-body text-center">
                        <h2>{{ $user->name }}</hs>
                        <h5>{{ $user->country_name }}</h5>
                        <p>{{ $user->gender }}</p>

                    <form method="post" action="{{ route('user.add_friend') }}" autocomplete="off">
                    @csrf
                    <input type="hidden" name="friend_id" value="{{ $user->uid }}" id="friend_id">
                    <div class="d-grid">
                    <button type="submit" class="btn btn-success d-block">Chat With {{ $user->name }}</button>
                        </div>
                    </form>
                    </div>

                </div>
                @endforeach



            </div>
            </div>
            <div class="col-md-4"></div>

       </div>
    </div>
</div>
@endsection
