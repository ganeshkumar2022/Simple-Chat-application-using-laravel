@extends('layout.master')
@section('title','Chat Application - Chat page')
@section('main-content')
<div class="dashboard-content w-100 overflow-hidden">
    <div class="row bg-dark">
        <div class="col-md-3 py-3 border border-light">
            <center>
                <a href="{{ route('user.dashboard') }}" class="btn btn-outline-light">Add New User</a>
            </center>
        </div>
        <div class="col-md-9 border py-3 border-light">
            @if ($chat_with)
            <table>
                <tr>
                    <td>
                        @if ($chat_with->profile_image==null)
                        <img src="{{ asset('assets/images/'.$chat_with->gender.'.png') }}" style="height:50px;width:50px;" class="rounded-circle">
                        @else
                        <img src="{{ asset('profile_images/'.$chat_with->profile_image) }}" style="height:50px;width:50px;" class="rounded-circle">
                        @endif
                    </td>
                    <td>
                        <div class="ms-3">
                        <span class="text-primary">{{ $chat_with->name }}</span> <br/>
                        <span class="text-secondary small">0 messages </span>
                        <a href="{{ route('user.logout') }}" class="btn btn-danger ms-3">Logout</a>
                        </div>
                    </td>
                </tr>
            </table>

            @endif
        </div>
    </div>
    <div class="row">
        <div class="col-md-3 bg-dark py-3 border border-light" style="height:90vh;overflow-x:hidden;overflow-y:scroll;">
            <table class="table-dark table-borderless table">
                @foreach ($friends_get as $friends)
                <tr class="p-2">
                    <td width="12%;">

                <a href="{{ route('user.chats',$friends->id) }}" class="text-decoration-none">
                        @if ($friends->profile_image==null)
                        <img src="{{ asset('assets/images/'.$friends->gender.'.png') }}" style="height:50px;width:50px;" class="rounded-circle">
                        @else
                        <img src="{{ asset('profile_images/'.$friends->profile_image) }}" style="height:50px;width:50px;" class="rounded-circle">
                        @endif
                    </a>
                    </td>
                    <td>

                        <a href="{{ route('user.chats',$friends->id) }}" class="text-decoration-none">
                                <span class="text-primary">{{ $friends->name }}</span> <br/>
                                @if($friends->is_active==1)
                                    <span class="text-success small"><i class="fa-solid fa-circle-dot"></i> Online </span>
                                @else
                                    <span class="text-secondary small"><i class="fa-solid fa-circle-dot"></i> Offline </span>
                                @endif
                        </a>
                    </td>
                </tr>
                @endforeach
            </table>
        </div>
        <div class="col-md-9 border py-3 border-light position-relative" style="height:90vh;overflow-x:hidden;overflow-y:scroll;">
            <!-- messages display start -->
            @if ($chat_with)
            <div class="row">
            @foreach ($my_messages as $mymessage)
            @if($mymessage->from_id==$iam->id)
                <div class="col-md-6 offset-6">
                <span class="text-end"><b>{{ $iam->name }}</b> {{ $mymessage->created_at }}</span>
                <div class="card mb-2" style="background-color:rgb(154, 206, 235);">
                    <div class="card-body">
                        {{ $mymessage->message }}
                    </div>
                </div>
                </div>
            @else
                <div class="col-md-6">
                    <span class="text-start"><b>{{ $chat_with->name }}</b> {{ $mymessage->created_at }}</span>
                <div class="card mb-2" style="background-color:rgb(175, 225, 175);">
                    <div class="card-body">
                        {{ $mymessage->message }}
                    </div>
                </div>
                </div>
                <div class="col-md-4"></div>
            @endif
            @endforeach
            </div>
            <!-- messages display end -->
            <div class="">
                 <form action="{{ route('user.send_message') }}" method="post" autocomplete="off">
                <div class="row bg-dark py-3 position-absolute fixed-bottom">
                    <div class="col-md-10">
                        @csrf
                        <input type="hidden" name="receiver_id" value="{{ $chat_with->id }}">
                        <input type="text" class="form-control ms-3" id="message" placeholder="Write your Message" name="message">
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn border ms-3 bg-white"><i class="fa-solid fa-paper-plane"></i></button>
                    </div>
                </form>
                </div>
            </div>
            @endif
        </div>
    </div>
</div>
@endsection
